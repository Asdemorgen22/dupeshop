# DupeShop
Flask + SQLite + vanilla JS. Run: `pip install -r requirements.txt && python app.py` (http://localhost:8000). Test: `pytest`.

## Deploy
`docker build -t dupeshop . && docker run -p 8000:8000 -v dupeshop-data:/data -e SITE_URL=https://yourdomain.com dupeshop`
Works as-is on Render, Fly.io, Railway or any Docker host. Set `SITE_URL` (canonical URLs, sitemap) and mount `/data` for the database. Put it behind HTTPS.

## Before going live
- **The catalog is demo data** (fictional retailers, illustrative prices, `.example` links). Replace `SEED` / the `products` table with a real feed (affiliate network APIs, retailer feeds) and real product images.
- Matching is a tag + colour similarity score, not a vision model. `match_score()` and `find_original()` are the swap points for image embeddings and live page parsing.
- Add rate limiting (e.g. Flask-Limiter) and your affiliate IDs on outbound links.

## Saved products
Hearts are stored in the `saved` table, keyed to an anonymous `ds_uid` cookie (1 year). No accounts yet, so clearing cookies or switching browsers starts a fresh list. Add login and swap `g.visitor` for the user id to sync across devices.
