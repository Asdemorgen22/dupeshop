import os, re, sqlite3, uuid
from urllib.parse import unquote
from flask import Flask, Response, g, jsonify, request

CATS = {"furniture": "Furniture", "fashion": "Fashion", "handbags": "Handbags",
        "shoes": "Shoes", "accessories": "Accessories", "home-decor": "Home Décor"}
ICON = {"furniture": "🛋️", "fashion": "🧥", "handbags": "👜", "shoes": "👟", "accessories": "💍", "home-decor": "💡"}
HEX = {"black": "#2b2b33", "camel": "#c19a6b", "white": "#e9e6df", "gold": "#d4af37", "silver": "#b8bcc4", "brown": "#7b5a3c"}
STOP = {"www", "com", "https", "http", "html", "product", "products", "shop", "the", "and", "for"}

# '*' = designer/original item. Format: name|retailer|price|color|tags. DEMO DATA: replace with a real feed.
SEED = """
#furniture
*Eames Lounge Chair & Ottoman|Herman Miller|6195|black|lounge chair,mid-century,leather,walnut,ottoman
Mid-Century Leather Lounge Chair|Haven Goods|1299|black|lounge chair,mid-century,leather,walnut
Walnut Lounge Chair & Ottoman|Casa Bella|489|black|lounge chair,mid-century,faux leather,walnut,ottoman
Plywood Recliner with Footstool|Northfield|329|brown|lounge chair,mid-century,leather,ottoman
#fashion
*Teddy Bear Icon Coat|Max Mara|2790|camel|coat,teddy,wool,long,camel
Camel Wool-Blend Long Coat|Thread & Co|229|camel|coat,wool,long,camel
Teddy Fleece Longline Coat|Lumen & Co|89|camel|coat,teddy,long,fleece
Oversized Camel Overcoat|Northfield|149|camel|coat,wool,long,oversized
#handbags
*Classic Flap Bag|Chanel|10200|black|quilted,flap,chain strap,leather,shoulder bag
Quilted Chain Shoulder Bag|Thread & Co|79|black|quilted,flap,chain strap,shoulder bag
Quilted Leather Flap Bag|Haven Goods|215|black|quilted,flap,chain strap,leather
Mini Quilted Crossbody|Lumen & Co|45|black|quilted,chain strap,crossbody
#shoes
*Super-Star Sneakers|Golden Goose|595|white|sneakers,distressed,leather,star,low-top
Distressed Star Leather Sneakers|StrideHub|89|white|sneakers,distressed,leather,star,low-top
Retro Star Low-Top Trainers|Thread & Co|59|white|sneakers,star,low-top
Vintage Court Sneakers|Northfield|75|white|sneakers,distressed,leather,low-top
#accessories
*Love Bracelet|Cartier|7350|gold|bracelet,gold,screw,bangle
Screw Motif Gold Bangle|Lumen & Co|68|gold|bracelet,gold,screw,bangle
Gold-Plated Open Cuff|Haven Goods|120|gold|bracelet,gold,bangle
Minimal Screw Bangle Set|Casa Bella|29|gold|bracelet,gold,screw
#home-decor
*Arco Floor Lamp|Flos|3400|silver|floor lamp,arc,marble,steel,modern
Arc Floor Lamp with Marble Base|Casa Bella|219|silver|floor lamp,arc,marble,steel
Modern Arched Floor Lamp|Northfield|129|black|floor lamp,arc,steel
Marble Base Arc Lamp|Haven Goods|159|silver|floor lamp,arc,marble,modern
"""


def slug(s):
    return re.sub(r"[^a-z0-9]+", "-", s.lower()).strip("-")


def init_db(path):
    os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
    db = sqlite3.connect(path)
    db.execute("""CREATE TABLE IF NOT EXISTS products(id INTEGER PRIMARY KEY, category TEXT NOT NULL, name TEXT NOT NULL,
        retailer TEXT NOT NULL, price REAL NOT NULL, color TEXT, tags TEXT, url TEXT UNIQUE, is_original INTEGER DEFAULT 0)""")
    db.execute("CREATE INDEX IF NOT EXISTS ix_cat ON products(category, is_original)")
    db.execute("""CREATE TABLE IF NOT EXISTS saved(visitor TEXT NOT NULL, product_id INTEGER NOT NULL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(visitor, product_id))""")
    if not db.execute("SELECT 1 FROM products").fetchone():
        cat = ""
        for line in SEED.strip().splitlines():
            if line.startswith("#"):
                cat = line[1:].strip()
                continue
            orig = line.startswith("*")
            name, retailer, price, color, tags = line.lstrip("*").split("|")
            host = slug(retailer).replace("-", "")
            url = f"https://www.{host}.example/{'products' if orig else 'p'}/{slug(name)}"
            db.execute("INSERT INTO products(category,name,retailer,price,color,tags,url,is_original) VALUES(?,?,?,?,?,?,?,?)",
                       (cat, name, retailer, float(price), color, tags, url, int(orig)))
        db.commit()
    db.close()


def pub(r):
    d = dict(r)
    d.pop("is_original", None)
    d["tags"] = d["tags"].split(",")
    d["category_label"] = CATS[d["category"]]
    d["image"] = f"/img/{d['id']}.svg"
    return d


def find_original(db, url):
    """Exact URL match first, then keyword overlap between the URL path and each original product."""
    norm = url.split("?")[0].split("#")[0].rstrip("/").lower()
    toks = {t for t in re.findall(r"[a-z]{3,}", unquote(norm)) if t not in STOP}
    best, top = None, 0
    for r in db.execute("SELECT * FROM products WHERE is_original=1"):
        if r["url"].lower() == norm:
            return r
        words = set(re.findall(r"[a-z]{3,}", f"{r['name']} {r['retailer']} {r['tags']}".lower())) - STOP
        if len(toks & words) > top:
            best, top = r, len(toks & words)
    return best if top >= 2 else None


def match_score(o, c):
    """Look-alike % = share of the original's style tags the dupe covers, plus a colour bonus."""
    a, b = set(o["tags"].split(",")), set(c["tags"].split(","))
    return round(100 * min(1, 0.85 * len(a & b) / len(a) + (0.15 if o["color"] == c["color"] else 0)))


def create_app(db_path=None):
    app = Flask(__name__, static_folder="static", static_url_path="/static")
    path = db_path or os.environ.get("DB_PATH", "data/dupeshop.db")
    init_db(path)

    def db():
        if "db" not in g:
            g.db = sqlite3.connect(path)
            g.db.row_factory = sqlite3.Row
        return g.db

    @app.teardown_appcontext
    def close(_):
        d = g.pop("db", None)
        if d:
            d.close()

    def site():
        return os.environ.get("SITE_URL", request.url_root).rstrip("/")

    @app.after_request
    def headers(r):
        r.headers.update({"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY",
                          "Referrer-Policy": "strict-origin-when-cross-origin"})
        if g.get("new_visitor") and request.path.startswith("/api/"):
            r.set_cookie("ds_uid", g.visitor, max_age=31536000, httponly=True, samesite="Lax", secure=request.is_secure)
        if request.path.startswith("/api/saved"):
            r.headers["Cache-Control"] = "no-store"
        return r

    @app.before_request
    def visitor():  # anonymous visitor id: lets saved items persist without accounts
        v = request.cookies.get("ds_uid", "")
        g.new_visitor = not re.fullmatch(r"[0-9a-f]{32}", v)
        g.visitor = uuid.uuid4().hex if g.new_visitor else v

    @app.get("/")
    def index():
        with open(os.path.join(app.static_folder, "index.html"), encoding="utf-8") as f:
            return Response(f.read().replace("%SITE%", site()), mimetype="text/html")

    @app.get("/health")
    def health():
        return {"status": "ok"}

    @app.get("/api/categories")
    def cats():
        return jsonify([{"id": k, "label": v} for k, v in CATS.items()])

    @app.get("/api/examples")
    def examples():
        cat, q, a = request.args.get("category", ""), "SELECT * FROM products WHERE is_original=1", ()
        if cat in CATS:
            q, a = q + " AND category=?", (cat,)
        return jsonify([pub(r) for r in db().execute(q + " ORDER BY price DESC", a)])

    @app.get("/api/dupes")
    def dupes():
        url = request.args.get("url", "").strip()
        if not url or len(url) > 2000:
            return jsonify(error="Paste a product link to get started."), 422
        try:
            max_price = float(request.args.get("max_price") or "inf")
            min_sav = float(request.args.get("min_savings") or 0)
        except ValueError:
            return jsonify(error="Max price and min savings must be numbers."), 422
        o = find_original(db(), url)
        if not o:
            return jsonify(error="We don't recognise that product yet. Try one of the popular finds below."), 404
        out = []
        for c in db().execute("SELECT * FROM products WHERE is_original=0 AND category=? AND price<?", (o["category"], o["price"])):
            d = pub(c)
            d["savings_amount"] = round(o["price"] - c["price"], 2)
            d["savings_pct"] = min(99, round(100 * d["savings_amount"] / o["price"]))
            d["match"] = match_score(o, c)
            d["overall"] = round(0.65 * d["match"] + 0.35 * d["savings_pct"], 1)
            if c["price"] <= max_price and d["savings_pct"] >= min_sav:
                out.append(d)
        out.sort(key=lambda d: (-d["match"], d["price"]))
        best = max(out, key=lambda d: d["overall"]) if out else None  # similarity weighted over savings
        return jsonify(original=pub(o), dupes=out, best_match=best)

    @app.get("/api/saved")
    def saved_list():
        rows = db().execute("SELECT p.* FROM saved s JOIN products p ON p.id=s.product_id WHERE s.visitor=? "
                            "ORDER BY s.created_at DESC, p.id DESC", (g.visitor,))
        return jsonify([pub(r) for r in rows])

    @app.route("/api/saved/<int:pid>", methods=["PUT", "DELETE"])
    def saved_toggle(pid):
        d, on = db(), request.method == "PUT"
        if on:
            if not d.execute("SELECT 1 FROM products WHERE id=?", (pid,)).fetchone():
                return jsonify(error="Unknown product."), 404
            d.execute("INSERT OR IGNORE INTO saved(visitor, product_id) VALUES(?,?)", (g.visitor, pid))
        else:
            d.execute("DELETE FROM saved WHERE visitor=? AND product_id=?", (g.visitor, pid))
        d.commit()
        return jsonify(saved=on, id=pid)

    @app.get("/img/<int:pid>.svg")
    def img(pid):
        r = db().execute("SELECT category,color FROM products WHERE id=?", (pid,)).fetchone()
        if not r:
            return Response(status=404)
        svg = ('<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 300 300"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1">'
               f'<stop offset="0" stop-color="{HEX.get(r["color"], "#999")}"/><stop offset="1" stop-color="#fff" stop-opacity=".3"/></linearGradient></defs>'
               f'<rect width="300" height="300" fill="url(#g)"/><text x="150" y="185" font-size="110" text-anchor="middle">{ICON[r["category"]]}</text></svg>')
        return Response(svg, mimetype="image/svg+xml", headers={"Cache-Control": "public,max-age=86400"})

    @app.get("/robots.txt")
    def robots():
        return Response(f"User-agent: *\nAllow: /\nDisallow: /api/\nSitemap: {site()}/sitemap.xml\n", mimetype="text/plain")

    @app.get("/sitemap.xml")
    def sitemap():
        return Response('<?xml version="1.0" encoding="UTF-8"?><urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">'
                        f'<url><loc>{site()}/</loc><changefreq>weekly</changefreq></url></urlset>', mimetype="application/xml")

    return app


if __name__ == "__main__":
    create_app().run(port=int(os.environ.get("PORT", 8000)), debug=True)
