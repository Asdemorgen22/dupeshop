import os, sys, pytest
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))
from app import create_app


@pytest.fixture
def c(tmp_path):
    return create_app(str(tmp_path / "t.db")).test_client()


def dupes(c, **q):
    return c.get("/api/dupes", query_string=q)


def test_pages_and_seo(c):
    home = c.get("/")
    assert b"Paste a product link" in home.data and b"%SITE%" not in home.data and b"application/ld+json" in home.data
    assert b"Sitemap:" in c.get("/robots.txt").data and b"<urlset" in c.get("/sitemap.xml").data
    assert c.get("/health").json["status"] == "ok" and len(c.get("/api/categories").json) == 6


def test_exact_url_returns_cheaper_dupes(c):
    ex = c.get("/api/examples?category=handbags").json[0]
    d = dupes(c, url=ex["url"]).json
    assert d["original"]["name"] == ex["name"] and len(d["dupes"]) == 3
    for x in d["dupes"]:
        assert x["price"] < ex["price"] and 0 < x["savings_pct"] < 100 and x["match"] > 0
        assert x["category"] == "handbags" and x["image"].startswith("/img/")


def test_real_world_url_is_matched_by_keywords(c):
    d = dupes(c, url="https://www.chanel.com/us/p/classic-flap-bag/?ref=ad").json
    assert d["original"]["retailer"] == "Chanel"


def test_filters(c):
    url = c.get("/api/examples?category=furniture").json[0]["url"]
    base = dupes(c, url=url).json["dupes"]
    capped = dupes(c, url=url, max_price=400).json["dupes"]
    assert capped and len(capped) < len(base) and all(d["price"] <= 400 for d in capped)
    deep = dupes(c, url=url, min_savings=90).json["dupes"]
    assert deep and all(d["savings_pct"] >= 90 for d in deep)


def test_every_category_has_dupes(c):
    for cat in c.get("/api/categories").json:
        o = c.get(f"/api/examples?category={cat['id']}").json
        assert o and dupes(c, url=o[0]["url"]).json["dupes"]


def test_errors_and_images(c):
    assert dupes(c).status_code == 422
    assert dupes(c, url="https://nothing.example/xyz").status_code == 404
    assert dupes(c, url="x", max_price="abc").status_code == 422
    assert c.get("/img/1.svg").mimetype == "image/svg+xml" and c.get("/img/9999.svg").status_code == 404


def test_best_match_is_strongest_and_respects_filters(c):
    url = c.get("/api/examples?category=handbags").json[0]["url"]
    d = dupes(c, url=url).json
    assert d["best_match"]["overall"] == max(x["overall"] for x in d["dupes"])
    assert dupes(c, url=url, max_price=50).json["best_match"]["price"] <= 50
    assert dupes(c, url=url, max_price=1).json["best_match"] is None


def test_saved_products_persist_and_are_private(tmp_path):
    path = str(tmp_path / "s.db")
    a = create_app(path).test_client()
    ids = [p["id"] for p in a.get("/api/examples").json[:2]]
    assert a.get("/api/saved").json == []
    for i in ids + ids[:1]:                                  # saving twice is harmless
        assert a.put(f"/api/saved/{i}").json == {"saved": True, "id": i}
    assert sorted(p["id"] for p in a.get("/api/saved").json) == sorted(ids)
    # "restart": brand-new app + client on the same database file, same visitor cookie
    b = create_app(path).test_client()
    b.set_cookie("ds_uid", a.get_cookie("ds_uid").value)
    assert sorted(p["id"] for p in b.get("/api/saved").json) == sorted(ids)
    # another visitor sees nothing
    assert create_app(path).test_client().get("/api/saved").json == []
    # unsaving persists too
    assert b.delete(f"/api/saved/{ids[0]}").json["saved"] is False
    assert [p["id"] for p in create_app(path).test_client().get("/api/saved").json] == []
    b2 = create_app(path).test_client(); b2.set_cookie("ds_uid", a.get_cookie("ds_uid").value)
    assert [p["id"] for p in b2.get("/api/saved").json] == [ids[1]]


def test_saving_unknown_product_fails(c):
    assert c.put("/api/saved/9999").status_code == 404
